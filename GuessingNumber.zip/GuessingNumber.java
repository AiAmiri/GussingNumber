import java.util.*;
public class GuessingNumber {
	public static void main(String[] args) {
	System.out.println("a random integer number betwin 0 and 100 is created ; can you guess it ?");
	Scanner input = new Scanner(System.in);
	Random rand =new Random();
	int rands=rand.nextInt(90)+10;
	do{
	int user=input.nextInt();
    if (user == rands) {
	System.out.println("random nuber was : "+rands);
	break;}
	else
	if (user != rands){
	if (user >= rands+10 || user <= rands-10) {
	System.out.println("you are far from random number");
	if ( user > rands)
	System.out.println("you are entered very big number");
	else 
	System.out.println("you are entered very small number");
	}
	else {
	System.out.println("you are near to random number");
	continue;}
	}
	} while (2==2);
	
}}